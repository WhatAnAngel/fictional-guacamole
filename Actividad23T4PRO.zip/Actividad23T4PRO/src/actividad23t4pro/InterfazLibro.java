package actividad23t4pro;

public interface InterfazLibro {
    
    boolean Prestar();
    boolean Devolver();
    String Prestado();
}
