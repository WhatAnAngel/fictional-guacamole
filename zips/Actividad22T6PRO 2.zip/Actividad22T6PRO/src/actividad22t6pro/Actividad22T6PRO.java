package actividad22t6pro;


public class Actividad22T6PRO {

    public static void main(String[] args) {

        Formulario miFormulario = new Formulario();
        miFormulario.setVisible(true);
    }

}
