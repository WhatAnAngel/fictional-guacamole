package veterinario;
import objetos.*;

public class Veterinario {

    public static void main(String[] args) {
        
        // Creamos instancia de animal

        Animal animalCompania = new Animal("Paul", "Pulpo", "267837");
        
        // Creamos instancia de persona
        
        Persona miPersona = new Persona("Angel", "50505050E", 24, animalCompania);
        
        System.out.println("Datos: " +  miPersona.mostrarDatos());
        
        System.out.println(Persona.mostrarPersonas());
        System.out.println(Animal.mostrarAnimales());
        
    }

}
