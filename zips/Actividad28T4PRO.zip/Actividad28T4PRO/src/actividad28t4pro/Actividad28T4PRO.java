package actividad28t4pro;

public class Actividad28T4PRO {

    public static void main(String[] args) {
        Vehiculo[] misVehiculos = new Vehiculo[4];
        Remolque miRemolque = new Remolque(50);
        
        misVehiculos[0] = new Coche(4, "67978990H");
        misVehiculos[1] = new Coche(5, "678547675HG");
        misVehiculos[2] = new Camion(null, "678547675HG");
        misVehiculos[3] = new Camion(miRemolque, "678547675HG");
        
        System.out.println(misVehiculos[2]);
        misVehiculos[2].acelerar(150);
        System.out.println(misVehiculos[2]);
        
        for (int i=0; i<misVehiculos.length; i++){
            
        }
    }
    
}
