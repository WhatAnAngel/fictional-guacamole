package ejemplojunit;


public class EjemploJUnit {

    public static void main(String[] args) {

    }

}
