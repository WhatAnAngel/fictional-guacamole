package concesionario;

public class Concesionario {

}
