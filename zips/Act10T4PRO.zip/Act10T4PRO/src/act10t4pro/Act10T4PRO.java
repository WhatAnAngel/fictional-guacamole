package act10t4pro;

public class Act10T4PRO {

    public static void main(String[] args) {
        
        System.out.println(Clima.calculaTiempo());

    }

}
