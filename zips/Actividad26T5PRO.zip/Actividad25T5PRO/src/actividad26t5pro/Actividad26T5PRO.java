package actividad26t5pro;


public class Actividad26T5PRO {

    public static void main(String[] args) {
        
    //Crear la clase dado, la cual desciende de la clase sorteo. La clase dado, en la 
    //llamada lanzar() mostrará un número aleatorio del 1 al 6.Crear la clase moneda, la cual 
    //desciende de la clase sorteo. Esta clase en la llamada al método lanzar() mostrará las palabras 
    //cara o cruz.

    }

}
