package actividad.pkg21t4pro;


public interface interEmpleado {
    
    double calculaPlus();
    double calculaRetencion();
    
}
