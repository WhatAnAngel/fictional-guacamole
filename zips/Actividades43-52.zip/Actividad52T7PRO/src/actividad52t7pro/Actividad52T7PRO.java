package actividad52t7pro;


public class Actividad52T7PRO {

    
    public static void main(String[] args) {
        String toMinus = "ESTO ES UNA PRUEBA DE TEXTO";
        String toMayus = "luis ros castro";
        System.out.println(toMinus.toLowerCase());
        System.out.println(toMayus.toUpperCase());
    }

}
