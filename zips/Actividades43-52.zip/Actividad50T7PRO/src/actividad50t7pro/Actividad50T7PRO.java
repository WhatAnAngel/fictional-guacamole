package actividad50t7pro;


public class Actividad50T7PRO {

    public static void main(String[] args) {
        
        String cadena = "     Agencia de Seguridad Nacional para la Defensa     ";
        System.out.println(cadena.trim());
    }

}
