package practicat6ede;


public class PracticaT6EDE {

    public static void main(String[] args) {
        Formulario miFormulario = new Formulario();
        miFormulario.setVisible(true);
    }

}
