package simulacroproact3;

public class SimulacroPROAct3 {
    public static void main(String[] args) {
        
        Formulario miFormulario = new Formulario();
        miFormulario.setVisible(true);
    }

}
